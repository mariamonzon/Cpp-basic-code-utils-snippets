/* 
 * File:   main.c
 * Author: Admin
 *
 * Created on 19 de octubre de 2014, 23:02
 */

#include <stdio.h>
#include <stdlib.h>

 
int main() 
{
//Declaracion
    int n1, n2, n3, p1, p2, p3;
    If
{    n1<n2
	If {n1<n3
		p1=n1
        If
        { n1<n2
                If {n1<n3
                        p1=n1
                else p1=n3}


                else p1=n3}
        else
                if{n2<n3
                        p1=n1
                else p1=n3}

    
       
    
    return 0 ;
}

