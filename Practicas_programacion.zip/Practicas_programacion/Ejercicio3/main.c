/* 
 * File:   main.c
 * Author: alumno
 *
 * Created on 17 de octubre de 2014, 13:28
 */

#include <stdio.h>
#include <stdlib.h>


int main() 
{//Declaracion
    int numero,cif1,cif2,cif3;
       //Introducir valores
    printf("Introduzca un numero entero de tres cifras:  ");
    scanf("%d", &numero);
    cif1=numero/100;
    cif2=numero/10%10;
    cif3=numero%10;
    
     //Mostrando resultados
     printf("Número invertido: %d%d%d", cif3,cif2,cif1);
    
    return (0);
}