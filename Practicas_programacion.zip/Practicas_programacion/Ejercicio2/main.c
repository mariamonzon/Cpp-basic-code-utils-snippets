/* 
 * File:   main.c
 * Author: alumno
 *
 * Created on 17 de octubre de 2014, 13:04
 */

#include <stdio.h>
#include <stdlib.h>



int main() 
{//Declaracion
    float celsius,fahrenheit;
       //Introducir valores
    printf("Introduzca el valor en grados Celsius:  ");
    scanf("%f", &celsius);
    
    //Calculo de la temperatura Fahrenheit
    fahrenheit= celsius*1.8+32;
    
    //Mostrar resultado de la operacion
     printf( "%.2fgrados Celsius = %.2f grados Fahrenheit\n",celsius,fahrenheit );
     
    return 0;
    
}

